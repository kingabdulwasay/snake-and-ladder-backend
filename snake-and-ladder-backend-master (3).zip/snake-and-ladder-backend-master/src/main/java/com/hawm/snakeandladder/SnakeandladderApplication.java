package com.hawm.snakeandladder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SnakeandladderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SnakeandladderApplication.class, args);
	}

}
