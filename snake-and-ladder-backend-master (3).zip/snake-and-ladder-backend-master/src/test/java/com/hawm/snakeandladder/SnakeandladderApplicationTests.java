package com.hawm.snakeandladder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SnakeandladderApplicationTests {

	@Test
	void contextLoads() {
	}

}
